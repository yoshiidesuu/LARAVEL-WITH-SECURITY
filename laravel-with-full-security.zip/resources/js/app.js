import './bootstrap';

// Import Bootstrap JavaScript
import * as bootstrap from 'bootstrap';
